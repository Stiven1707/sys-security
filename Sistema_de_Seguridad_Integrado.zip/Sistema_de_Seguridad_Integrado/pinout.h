#include "AsyncTaskLib.h"
#include "DHTStable.h"
#include "StateMachineLib.h"
#include <LiquidMenu.h>
#include <EEPROM.h>
#include <Keypad.h> 
#include <LiquidCrystal.h>
#define LED_RED_PIN 51  
#define LED_GREEN_PIN 52  
#define LED_BLUE_PIN 53  
#define DHT11_PIN 50
#define BUZZER_PASIVO 47
#define NOTE_FS6 1480
#define NOTE_G6  1568  
#define A_TEMP_H 1
#define A_TEMP_L 0
#define A_LUZ 2
#define A_SONIDO 6

//ENCODER
#define outputA 16
#define outputB 17
#define sw 14

#define incrementoEncoder 1

int address = 0;
int value;
byte valorTempH;
byte valorTempL;
int valorLuz;
short valorSonido;

byte minValor = 0;
byte maxValor = 4;
int melodia[] = {
  NOTE_FS6, NOTE_G6
};

int duraciones[] = {
  8, 8
};

const byte TH_TEMP_LOW =25;
const byte TH_TEMP_NORM = 29;
const byte TH_TEMP_HIGH = 30;

const byte TH_TEMP_MAX = 50;
const byte TH_TEMP_MIN = 0;
const int TH_LUZ_HIGH = 1023;
const short TH_SON_HIGH = 25;

/*
 * Declaracion de los pines de la LCD
 */
const int rs = 12, en = 11, d4 = 31, d5 = 32, d6 = 33, d7 = 34;//cambio
LiquidCrystal lcd(rs, en, d4, d5, d6, d7);
/*
 * Declaracion del teclado 
 */
// include the library code:
unsigned long sysloked_Actual;
unsigned long sysloked_delta;
unsigned long sysloked_Anterior = 0;
int contador = 0;

int indice = 0;
int intentos = 0; //3
bool banderaPassword = false;
const byte ROWS = 4; //four rows
const byte COLS = 3; //three columns
char keys[ROWS][COLS] = {
  {'1', '2', '3'},
  {'4', '5', '6'},
  {'7', '8', '9'},
  {'*', '0', '#'}
};
byte letra1[8] = { B00000, B01010, B11111, B11111, B11111, B01110, B00100, B00000 };
byte letra2[8] = { B00000, B01010, B10101, B10001, B10001, B01010, B00100, B00000 };
char PASSWORD[5] =  "2001";
char PASSWORD_USER[5];
byte rowPins[ROWS] = {2, 3, 4, 5}; //connect to the row pinouts of the keypad
byte colPins[COLS] = {6, 7, 8}; //connect to the column pinouts of the keypad
Keypad keypad = Keypad( makeKeymap(keys), rowPins, colPins, ROWS, COLS );

/*
 * Encabezados para el llamado de funciones.
 */
void validarIntentos();
void leerTeclado(); 
void validarPassword();
void tiempoMuerto();
void limpiarPasswrd();
void leer_FotoRes(void);
void leer_micro(void);
void timeout_T1();
void measure_Temp();
void selectOption();
void rotacionEncoder();
void inicializarPantallas();
/*
 * Sensor luz
 */

const int photocellPin = A0;
const int ledPin = 13;
int valor_FotoRes = 0;
/*
 * microfono
 */
const int soundPin = A2;
int valor_micro = 0;


/*
 * Declaración de instancia del sensor de temperatura 
 */
DHTStable DHT;

/*
 * inicialización de encoder y menú 
 */
 int value_Temp;
int aState;
int aLastState;
int opc_Seleccionada = 0;
bool opSave = false;
bool opCancel = false;
LiquidLine linea1(1, 0, "Umb Temp High");
LiquidLine linea2(1, 1, "Umb Temp Low");
LiquidLine linea3(1, 0, "Umb light");
LiquidLine linea4(1, 1, "Umb Sound");
LiquidLine linea5(1, 0, "Save");
LiquidLine linea6(1, 1, "Cancel");
LiquidLine linea7(1, 0, "Reset");

LiquidScreen pantalla1;

LiquidLine linea1_2(1, 1, value);

LiquidScreen pantalla2(linea1_2);

LiquidMenu menu(lcd, pantalla1, pantalla2);

/*
 * Declaración de tareas asíncronas 
 */


AsyncTask asyncTaskTiempoFuera(10000, timeout_T1);
AsyncTask asyncTaskTemperatura(500, true, measure_Temp);
AsyncTask asyncTaskFotoRes(2000, true, leer_FotoRes);
AsyncTask asyncTaskMicrofono(3000, true, leer_micro);

/********************************************//**
    State Machine control functions
 ***********************************************/

/*
   @brief define los estados de la máquina
*/
enum State
{
  INICIO = 0,
  CONFIG = 1,
  RUN = 2,
  ALARM = 3
};

/*
   @brief Define las enttradas de estados de la máquina
*/
enum Input
{
  Sign_Siguiente = 1,
  Sign_Anterior = 2,
  Sign_Especial = 3,
  Unknown = 4,
  Sign_Init_Run = 5,
};

/*! Stores last user input */
Input currentInput;

/*
 * Instancia de la máquina de estados con 4 estados y 7 transiciones 
 */
StateMachine stateMachine(4, 7);
